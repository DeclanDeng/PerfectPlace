﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PerfectPlace.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public String Name { get; set; }
    }

    // Movie/random
}